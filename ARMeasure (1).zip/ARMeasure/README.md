# AR Measure (Android)

Measure lengths with your phone camera using Google ARCore.

## How to use
1. Open the app and slowly move the phone so it can map the room.
2. When the crosshair turns **green**, it's on a surface.
3. Aim at the start point, tap **+ Add point**.
4. Aim at the end point; the live length shows as you move. Tap **+ Add point** again.
5. Keep adding points to chain measurements (total shown at the top).
   **Undo** removes the last point, **Clear** starts over.

## Build & install
1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this project, then in Android Studio: File > Open > select the `ARMeasure` folder.
   Let Gradle sync finish (first time downloads dependencies).
3. On your phone: Settings > About phone > tap "Build number" 7 times to enable
   Developer options, then turn on **USB debugging**.
4. Plug the phone in, pick it in the device dropdown, press the green Run ▶ button.
5. To get an installable APK instead: Build > Build App Bundle(s)/APK(s) > Build APK(s).

## Requirements
- An ARCore-supported phone (most mid/high-end Androids since ~2018):
  https://developers.google.com/ar/devices
- Google Play Services for AR (the app prompts to install it if missing).

## Accuracy tips
- Typical accuracy is around 1–2 cm per metre; phones with a depth (ToF) sensor do better.
- Good, even lighting and textured surfaces help. Plain white walls are hardest.
- Hold the phone 0.5–1.5 m from what you're measuring and move slowly.
- Use it for quick estimates; verify with a tape for anything you're cutting or ordering.
