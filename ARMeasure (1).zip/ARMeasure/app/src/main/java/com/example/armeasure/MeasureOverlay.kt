package com.example.armeasure

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import java.util.Locale

data class OverlayState(
    val points: List<PointF?>,        // null = point is behind the camera
    val segmentLengths: List<Float>,  // metres
    val liveLength: Float?,           // last point -> crosshair, metres
    val onSurface: Boolean,
)

fun formatLength(m: Float): String =
    if (m < 1f) String.format(Locale.UK, "%.1f cm", m * 100f)
    else String.format(Locale.UK, "%.2f m", m)

class MeasureOverlay @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: OverlayState? = null
    private val d = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; strokeWidth = 3 * d; style = Paint.Style.STROKE
    }
    private val livePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; strokeWidth = 2 * d; style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(10 * d, 8 * d), 0f)
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFC107"); style = Paint.Style.FILL
    }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 0, 0, 0); style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 16 * d; textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val reticleOk = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4CAF50"); strokeWidth = 3 * d; style = Paint.Style.STROKE
    }
    private val reticleBad = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F44336"); strokeWidth = 3 * d; style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val s = state

        if (s != null) {
            val pts = s.points
            for (i in 1 until pts.size) {
                val a = pts[i - 1]
                val b = pts[i]
                if (a != null && b != null) {
                    canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
                    label(canvas, (a.x + b.x) / 2, (a.y + b.y) / 2, formatLength(s.segmentLengths[i - 1]))
                }
            }
            val last = pts.lastOrNull()
            val live = s.liveLength
            if (last != null && live != null) {
                canvas.drawLine(last.x, last.y, cx, cy, livePaint)
                label(canvas, (last.x + cx) / 2, (last.y + cy) / 2 - 24 * d, formatLength(live))
            }
            pts.forEach { p -> if (p != null) canvas.drawCircle(p.x, p.y, 6 * d, pointPaint) }
        }

        // Crosshair: green = on a surface, red = no surface found
        val r = if (s?.onSurface == true) reticleOk else reticleBad
        canvas.drawCircle(cx, cy, 16 * d, r)
        canvas.drawLine(cx - 6 * d, cy, cx + 6 * d, cy, r)
        canvas.drawLine(cx, cy - 6 * d, cx, cy + 6 * d, r)
    }

    private fun label(c: Canvas, x: Float, y: Float, text: String) {
        val w = textPaint.measureText(text) + 16 * d
        val h = textPaint.textSize + 10 * d
        c.drawRoundRect(x - w / 2, y - h / 2, x + w / 2, y + h / 2, 8 * d, 8 * d, labelBg)
        c.drawText(text, x, y + textPaint.textSize / 3, textPaint)
    }
}
