package com.example.armeasure

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.PointF
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Camera
import com.google.ar.core.Config
import com.google.ar.core.DepthPoint
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import com.google.ar.core.Point
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingFailureReason
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), GLSurfaceView.Renderer {

    private lateinit var surfaceView: GLSurfaceView
    private lateinit var overlay: MeasureOverlay
    private lateinit var status: TextView

    private var session: Session? = null
    private var installRequested = false
    private var permissionDenied = false
    @Volatile private var textureSet = false
    @Volatile private var displayChanged = true

    private val background = BackgroundRenderer()
    private val anchors = mutableListOf<Anchor>()          // touched on GL thread only
    private val addRequested = AtomicBoolean(false)

    private var viewWidth = 0
    private var viewHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        surfaceView = findViewById(R.id.surface)
        overlay = findViewById(R.id.overlay)
        status = findViewById(R.id.status)

        surfaceView.preserveEGLContextOnPause = true
        surfaceView.setEGLContextClientVersion(2)
        surfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        surfaceView.setRenderer(this)
        surfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        findViewById<Button>(R.id.btnAdd).setOnClickListener { addRequested.set(true) }
        findViewById<Button>(R.id.btnUndo).setOnClickListener {
            surfaceView.queueEvent { anchors.removeLastOrNull()?.detach() }
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            surfaceView.queueEvent {
                anchors.forEach { it.detach() }
                anchors.clear()
            }
        }
    }

    // ---------- Lifecycle ----------

    override fun onResume() {
        super.onResume()
        if (permissionDenied) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            return
        }

        if (session == null) {
            try {
                val install = ArCoreApk.getInstance().requestInstall(this, !installRequested)
                if (install == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                    installRequested = true
                    return
                }
                val s = Session(this)
                configure(s)
                session = s
                textureSet = false
            } catch (e: UnavailableDeviceNotCompatibleException) {
                fail("Sorry, this phone doesn't support ARCore."); return
            } catch (e: UnavailableUserDeclinedInstallationException) {
                fail("Google Play Services for AR is required."); return
            } catch (e: Exception) {
                fail("AR unavailable: ${e.message}"); return
            }
        }

        try {
            session?.resume()
        } catch (e: CameraNotAvailableException) {
            fail("Camera unavailable. Close and reopen the app.")
            session = null
            return
        }
        surfaceView.onResume()
        displayChanged = true
    }

    override fun onPause() {
        super.onPause()
        if (session != null) {
            surfaceView.onPause()
            session?.pause()
        }
    }

    override fun onDestroy() {
        session?.close()
        session = null
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAMERA &&
            grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED
        ) {
            permissionDenied = true
            fail("Camera permission is needed to measure. Enable it in Settings.")
        }
    }

    private fun configure(s: Session) {
        val config = Config(s).apply {
            planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
            focusMode = Config.FocusMode.AUTO
            updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
            if (s.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) {
                depthMode = Config.DepthMode.AUTOMATIC
            }
        }
        s.configure(config)
    }

    // ---------- GL renderer ----------

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        background.createOnGlThread()
        textureSet = false
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        viewWidth = width
        viewHeight = height
        displayChanged = true
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val s = session ?: return

        if (!textureSet) {
            s.setCameraTextureName(background.textureId)
            textureSet = true
        }
        if (displayChanged) {
            @Suppress("DEPRECATION")
            s.setDisplayGeometry(windowManager.defaultDisplay.rotation, viewWidth, viewHeight)
            displayChanged = false
        }

        val frame = try { s.update() } catch (e: Exception) { return }
        background.draw(frame)

        val camera = frame.camera
        if (camera.trackingState != TrackingState.TRACKING) {
            addRequested.set(false)
            post(OverlayState(emptyList(), emptyList(), null, false), trackingMessage(camera))
            return
        }

        // Hit test from the crosshair in the centre of the screen
        val hit = frame.hitTest(viewWidth / 2f, viewHeight / 2f).firstOrNull { isGoodHit(it) }

        if (addRequested.getAndSet(false)) {
            if (hit != null) {
                anchors.add(hit.createAnchor())
            } else {
                runOnUiThread {
                    Toast.makeText(this, "No surface under the crosshair yet", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // World -> screen projection
        val proj = FloatArray(16)
        val view = FloatArray(16)
        val vp = FloatArray(16)
        camera.getProjectionMatrix(proj, 0, 0.05f, 100f)
        camera.getViewMatrix(view, 0)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        val poses = anchors.filter { it.trackingState != TrackingState.STOPPED }.map { it.pose }
        val screen = poses.map { project(vp, it) }
        val segments = (1 until poses.size).map { distance(poses[it - 1], poses[it]) }
        val live = if (hit != null && poses.isNotEmpty()) distance(poses.last(), hit.hitPose) else null

        val msg = when {
            poses.isEmpty() && hit == null -> "Move the phone slowly to find a surface"
            poses.isEmpty() -> "Aim the circle at the start, tap + Add point"
            segments.isEmpty() -> "Start set. Aim at the end point" +
                (live?.let { "  (${formatLength(it)})" } ?: "")
            else -> "Total: ${formatLength(segments.sum())}" +
                (live?.let { "   next: ${formatLength(it)}" } ?: "")
        }
        post(OverlayState(screen, segments, live, hit != null), msg)
    }

    // ---------- Helpers ----------

    private fun isGoodHit(hit: HitResult): Boolean = when (val t = hit.trackable) {
        is Plane -> t.isPoseInPolygon(hit.hitPose)
        is DepthPoint -> true
        is Point -> t.orientationMode == Point.OrientationMode.ESTIMATED_SURFACE_NORMAL
        else -> false
    }

    private fun project(vp: FloatArray, pose: Pose): PointF? {
        val out = FloatArray(4)
        Matrix.multiplyMV(out, 0, vp, 0, floatArrayOf(pose.tx(), pose.ty(), pose.tz(), 1f), 0)
        if (out[3] <= 0f) return null // behind the camera
        val x = (out[0] / out[3] + 1f) * 0.5f * viewWidth
        val y = (1f - out[1] / out[3]) * 0.5f * viewHeight
        return PointF(x, y)
    }

    private fun distance(a: Pose, b: Pose): Float {
        val dx = a.tx() - b.tx()
        val dy = a.ty() - b.ty()
        val dz = a.tz() - b.tz()
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun trackingMessage(c: Camera): String = when (c.trackingFailureReason) {
        TrackingFailureReason.INSUFFICIENT_LIGHT -> "Too dark. Add more light"
        TrackingFailureReason.EXCESSIVE_MOTION -> "Moving too fast. Slow down"
        TrackingFailureReason.INSUFFICIENT_FEATURES -> "Point at a surface with some texture"
        TrackingFailureReason.CAMERA_UNAVAILABLE -> "Camera unavailable"
        else -> "Move the phone slowly to start…"
    }

    private fun post(state: OverlayState, msg: String) {
        runOnUiThread {
            overlay.state = state
            overlay.invalidate()
            status.text = msg
        }
    }

    private fun fail(msg: String) {
        runOnUiThread { status.text = msg }
    }

    companion object {
        private const val REQ_CAMERA = 1
    }
}
